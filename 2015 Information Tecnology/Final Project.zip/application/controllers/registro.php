<?php
class Registro extends CI_Controller{
	
	public function __construct()
       {
        parent::__construct();
        $this->load->helper('form');
		$this->load->helper('url');
		$this->load->library('session');
		$this->load->database();
		$this->load->model('users_model');
	}
	
	function index(){
		#Verificamos si el usuario esta logeado. Si es distinto de false, el usuario esta logeado y no debe poder acceder al registro.
		if($this->session->userdata('usuario') != FALSE){	
			redirect('/login','refresh');
		}
		#Caso contrario, le mostramos la vista del registro.
		else{
			$view_info['message']="";
			$this->load->view('registro_view', $view_info);
		}
	}
	#Esta funcion se encarga de procesar el formulario y crear un nuevo registro de usuario en la BD.
	function new_user(){
		#Verificamos que esten todos los campos seteados.
		if(isset($_POST['nombre'])&&isset($_POST['usuario'])&&isset($_POST['contrasena'])&&isset($_POST['apellido'])&&isset($_POST['correo'])&&$_POST['nombre']!=''&&$_POST['usuario']!=''&&$_POST['contrasena']!=''&&$_POST['apellido']!=''&&$_POST['correo']!=''&& $_FILES["avatar"]["size"] > 0){
			$user=$_POST['usuario'];
			$user_taken = $this->users_model->user_exists($user);
			#Aqui vemos si el usuario escogido esta disponible o no.
			#Si no esta disponible entonces user_exists devuelve la info. correspondiente a ese username. Si no, es igual a null.
			if ($user_taken != null){
				//usuario ya tomado
				$view_info['message']="Usuario ya tomado, porfavor intente uno distinto.";
				$this->load->view('registro_view',$view_info);
			}
			else{
				#Estas dos instrucciones son para sacar la extension del  archivo.
				$path = $_FILES['avatar']['name'];
				$ext = pathinfo($path, PATHINFO_EXTENSION);
				#Receta para subir imagenes con codeigniter sacada de: http://www.formget.com/codeigniter-upload-image/.
				//Seteamos las configuraciones deseadas para la carga de la imagen.
				$config['upload_path'] = './uploads/';
				$config['allowed_types'] = 'gif|jpg|png';
				$config['file_name'] = $user;
				$config['max_size'] = 1000;
				$config['max_width'] = 1000;
				$config['max_height'] = 1000;
 				$this->load->library('upload', $config);
				$this->upload->initialize($config);
				$this->upload->set_allowed_types('*');
				#Si la imagen se sube con exito entonces guardamos el usuario en la BD.
				if($this->upload->do_upload('avatar')){
					$this->users_model->save_user($_POST['nombre'],$_POST['apellido'],$_POST['sexo'],$user.".".$ext,$_POST['correo'],$_POST['usuario'],$_POST['contrasena']);
					$view_info['message']="Datos ingresados al sistema!";
					$this->load->view('registro_view',$view_info);
				}
				#Si no, mostramos el error correspondiente. Codeigniter provee una funcion para mostrar el error de un upload.
				else{
					echo  $this->upload->display_errors();
					$view_info['message']= 'Porfavor intente con otra imagen';
					$this->load->view('registro_view',$view_info);
				}
			}
				
		}
		#Si los campos no estan todos llenos mostramos este mensaje.
		else{
			$view_info['message']="Por favor, llene todas las casillas.";
			$this->load->view('registro_view',$view_info);
		}
	}

}


?>