<?php
class Admin extends CI_Controller{
	
	public function __construct(){
        parent::__construct();
        $this->load->helper('form');
		$this->load->helper('url');
		$this->load->library('session');
		$this->load->database();
		$this->load->model('users_model');
		$this->load->model('productos_model');
		$this->load->model('ventas_model');
		
		$view_info = array();
	}
	
	
	function index(){
		#Chequeamos si el usuario es adm o no.
		if($this->session->userdata('status')=='administrator' ){
			$ventas = $this->ventas_model->get_venta();
			$view_info['ventas'] = $ventas;
			$view_info['message']="";
			$view_info['message_adm']="";
			$this->load->view('menu_view',$view_info);
			$this->load->view('admin_view',$view_info);
		}
		#Si no lo es, lo redirigimos al login.
		else{
			redirect('/login','referesh');
		}
		
	}
	#Agrega productos nuevos a la BD.
	function agregar_productos(){
		$ventas = $this->ventas_model->get_venta();
		$view_info['ventas'] = $ventas;
		$view_info['message']="";
		#Vemos si estan todos los campos llenos antes que nada.
		if(isset($_POST['producto'])&&isset($_POST['precio'])&&($_FILES['imagen2']['size']>0)&&isset($_POST['talla'])&&isset($_POST['comentario'])&&isset($_POST['cantidad'])) {
			if($_POST['producto']!=''&&$_POST['precio']!=''&&$_POST['talla']!=''&&$_POST['comentario']!=''&&$_POST['cantidad']!=''){
					$check_product = $this->productos_model->check_product($_POST['producto']);
					#Antes de agregar algo tenemos que chequear que ese producto no exista en la BD.
					if($check_product != null){
						$view_info['message_adm'] = "Producto ya existe.";
						$this->load->view('menu_view',$view_info);
						$this->load->view('admin_view',$view_info);
					}
					else{
						#Este metodo para subir imagenes por codeigniter fue sacado de: http://www.formget.com/codeigniter-upload-image/.
						$path = $_FILES['imagen2']['name'];
						$ext = pathinfo($path, PATHINFO_EXTENSION);
						//Seteamos las configuraciones deseadas para la carga de la imagen.
						$config['upload_path'] = './product_img/';
						$config['allowed_types'] = 'gif|jpg|png';
						$config['file_name'] = $_POST['producto'];
						$config['max_size'] = 1000;
						$config['max_width'] = 1000;
						$config['max_height'] = 1000;
		 				$this->load->library('upload', $config);
						$this->upload->initialize($config);
						$this->upload->set_allowed_types('*');
						#Si la imagen se sube exitosamente entonces escribimos la BD.
						if($this->upload->do_upload('imagen2')){
							$this->productos_model->save_product($_POST['producto'],$_POST['precio'],$_POST['cantidad'],$_POST['producto'].".".$ext,$_POST['talla'],$_POST['comentario']);
							$view_info['message_adm']="Producto Agregado.";
							$this->load->view('menu_view',$view_info);
							$this->load->view('admin_view',$view_info);
						}
						#Si no mostramos un error.
						else{
							echo  $this->upload->display_errors();
							$view_info['message_adm']= 'Porfavor intente con otra imagen';
							$this->load->view('menu_view',$view_info);
							$this->load->view('admin_view',$view_info);
						}
					}
			}
			#Si no estan todos los campos llenos, mostramos un mensaje que lo dice. (Este es el caso de algo con ' ').
			else{
				$view_info['message_adm']="Por favor, llene todas las casillas.";
				$this->load->view('menu_view',$view_info);
				$this->load->view('admin_view',$view_info);
			}

			
		}
		#Este es el caso en que simplemente los campos no estan seteados.
		else{
			$view_info['message_adm']="Por favor, llene todas las casillas.";
			$this->load->view('menu_view',$view_info);
			$this->load->view('admin_view',$view_info);
		}

	}
	#Cambia el status de un usuario de activo a banneado o a adm.
	function estado_usuario(){
		$ventas = $this->ventas_model->get_venta();
		$view_info['ventas'] = $ventas;
		$view_info['message']='';
		#Vemos que el campo este seteado y no contenga espacios vacios.
    	if(isset($_POST['status'])){
			if($_POST['status']!=''){
				if($_POST['usuario3']!=''){
					#Chequeamos que el usuario a modificar exista en la BD.
					$check_user = $this->users_model->check_username($_POST['usuario3']);
					#Si es que el post tiene algo distinto de borrar entonces cambiamos el status del usuario.
					if($_POST['status']!='borrar'){
						if($check_user != null){
							$this->users_model->update_status($_POST['usuario3'],$_POST['status']);
							$view_info['message_adm']='Estado del <br> usuario cambiado.';
							$this->load->view('menu_view',$view_info);
							$this->load->view('admin_view',$view_info);
						}
						#Si el usuario no existe comunicamos el error.
						else{
							$view_info['message_adm'] = 'El usuario ingresado <br> no existe, inténtelo <br> nuevamente.';
							$this->load->view('menu_view',$view_info);
							$this->load->view('admin_view',$view_info);
						}
					}
					#Si el post dice que se quiere borrar al usuario, repetimos el proceso anterior.
					else{
						#Verificamos que el usuario exista en la BD.
						#Si existe, entonces lo borramos.
						if($check_user != null){
							$this->users_model->delete_user($_POST['usuario3']);
							$view_info['message_adm'] = 'Usuario eliminado.';
							$this->load->view('menu_view',$view_info);
							$this->load->view('admin_view',$view_info);

						}
						#Si no, comunicamos el error.
						else{
							$view_info['message_adm'] = 'El usuario ingresado <br> no existe, inténtelo <br> nuevamente.';
							$this->load->view('menu_view',$view_info);
							$this->load->view('admin_view',$view_info);
						}
					}
				}
				#Caso en que se ingresa espacios vacios en el campo del formulario.
				else{
					$view_info['message_adm'] = "Por favor, llene <br> todos los espacios.";
					$this->load->view('menu_view',$view_info);
					$this->load->view('admin_view',$view_info);
				}
			}
			#Caso en que no estan todos los campos seteados.
			else{
				$view_info['message_adm'] = "Por favor, llene <br> todos los espacios.";
				$this->load->view('menu_view',$view_info);
				$this->load->view('admin_view',$view_info);
			}
		}
		#Caso en que no se marca la accion que se quiere tomar con el status (borrar, bannear,adm, activar)
		else{
			$view_info['message_adm'] = "Por favor, llene <br> todos los espacios.";
			$this->load->view('menu_view',$view_info);
			$this->load->view('admin_view',$view_info);
		}
	}

	#Modifica cualquier producto de la BD.
	function modificar_producto(){
		$ventas = $this->ventas_model->get_venta();
		$view_info['ventas'] = $ventas;
		$view_info['message']="";
		$view_info['message_adm'] ='';
		#En todos los casos debemos chequear que se envie un nombre de producto, para poder identificarlo y hacer los cambios correspondientes en la BD.
		#Si se quiere cambiar el nombre del producto
		if(!isset($_POST['producto2']) or $_POST['producto2']==''){
			$view_info['message_adm']= 'Porfavor ingresa el nombre del producto a modificar';	
		}
		#Si se quiere cambiar el precio
		if(isset($_POST['precio2'])){
			if($_POST['precio2']!=''&&$_POST['producto2']!=''){
				$this->productos_model->modify_product_price($_POST['producto2'],$_POST['precio2']);
				$view_info['message_adm'] = '<br>Atributo(s) modificado(s).';
			}
		}
		#Si se quiere cambiar la cantidad.
		if(isset($_POST['cantidad2'])){
			if($_POST['cantidad2']!=''&&$_POST['producto2']!=''){
				$this->productos_model->modify_product_amount($_POST['producto2'],$_POST['cantidad2']);
				$view_info['message_adm'] = '<br>Atributo(s) modificado(s).';
			}
		}
		#Si se quiere cambiar la talla.
		if(isset($_POST['talla2'])){
			if($_POST['talla2']!=''&&$_POST['producto2']!=''){
				$this->productos_model->modify_product_size($_POST['producto2'],$_POST['talla2']);
				$view_info['message_adm'] = '<br>Atributo(s) modificado(s).';
			}
		}
		#Si se quiere cambiar el comentario.
		if(isset($_POST['comentario2'])){
			if($_POST['comentario2']!=''&&$_POST['producto2']!=''){
				$this->productos_model->modify_product_comment($_POST['producto2'],$_POST['comentario2']);
				$view_info['message_adm'] = '<br>Atributo(s) modificado(s).';
			}
		}
		#Si se quiere subir alguna imagen nueva.
		if($_FILES['imagen3']['size']>0){
			if($_POST['producto2']!=''){
				#var_dump($_FILES["avatar"]);
				$path = $_FILES['imagen3']['name'];
				$ext = pathinfo($path, PATHINFO_EXTENSION);
				//Seteamos las configuraciones deseadas para la carga de la imagen.
				$config['upload_path'] = './product_img/';
				$config['allowed_types'] = 'gif|jpg|png';
				$config['file_name'] = $_POST['producto2'];
				$config['max_size'] = 1000;
				$config['max_width'] = 1000;
				$config['max_height'] = 1000;
				//Ahora sobre escribimos la imagen antigua.
				$config['overwrite'] = TRUE;
 				$this->load->library('upload', $config);
				$this->upload->initialize($config);
				$this->upload->set_allowed_types('*');
				if($this->upload->do_upload('imagen3')){
					$this->productos_model->modify_product_picture($_POST['producto2'],$_POST['producto2'].".".$ext);
					$view_info['message_adm'] = '<br>Atributo(s) modificado(s).';
					$this->load->view('menu_view',$view_info);
					$this->load->view('admin_view',$view_info);
				}
				else{
					$view_info['message_adm']= $this->upload->display_errors();
					echo $this->upload->display_errors();
					$this->load->view('menu_view',$view_info);
					$this->load->view('admin_view',$view_info);
				}
			}
		}
		else{
			$view_info['message_adm'] = 'Porfavor rellene algun campo a modificar';
			$this->load->view('menu_view',$view_info);
			$this->load->view('admin_view',$view_info);
		}
	}
}