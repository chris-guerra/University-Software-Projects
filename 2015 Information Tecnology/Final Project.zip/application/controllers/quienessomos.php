<?php
class Quienessomos extends CI_Controller{
	
	public function __construct()
       {
        parent::__construct();
        $this->load->helper('form');
		$this->load->helper('url');
		$this->load->library('session');
		$this->load->database();
		$this->load->model('users_model');
		
		$view_info = array();
	}
	#Controlador que solo carga la vista correspondiente al quienes somos.
	function index(){
		$data = $this->session->all_userdata(); 
		if($this->session->userdata('usuario') != FALSE){
			if($this->session->userdata('status')=='administrator'){
				$view_info['message']="Si desea ingresar a la<br> página de administrador <br>haga click <a class='enlace' href='http://localhost/tarea3grupo4/index.php/admin' >aquí</a>.";
			}
			else{ 
				$view_info['message']= "";
			}
			$this->load->view('menu_view',$view_info);
			$this->load->view('quienessomos_view');
		}
		else{
		}
	}	
}
	

?>