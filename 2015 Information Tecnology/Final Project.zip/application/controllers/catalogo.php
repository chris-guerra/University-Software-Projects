<?php
class Catalogo extends CI_Controller{
	
	public function __construct(){
        parent::__construct();
        $this->load->helper('form');
		$this->load->helper('url');
		$this->load->library('session');
		$this->load->database();
		$this->load->model('users_model');
		$this->load->model('productos_model');
		
		$view_info = array();

	}
	
	function index(){
		if($this->session->userdata('usuario') != TRUE){
			redirect('/login','refresh');
		}
		else{
			#Si el usuario esta logeado entonces buscamos todos los productos en la BD para mostrarlos en la vista.
			$data['row_productos'] = $this->productos_model->get_product();
			if($this->session->userdata('status')=='administrator'){
				$data['message']="Si desea ingresar a la<br> página de administrador <br>haga click <a class='enlace' href='http://localhost/tarea3grupo4/index.php/admin' >aquí</a>.";
				$this->load->view('menu_view',$data);
				$this->load->view('catalogo_view',$data);
			}
			else{
				$data['message']="";
				$this->load->view('menu_view',$data);
				$this->load->view('catalogo_view',$data);
			}
		}
	}
	#Muestra la vista correspondiente al detalle de algun producto seleccionado por el usuario.
	function ver_detalle(){
		#En este post viene el identificador del producto en la base. El item. 
		$producto = $_POST['producto'];
		#Obtenemos la info. correspondiente al producto solicitado. Para mostrarla en la vista
		$data['producto'] = $this->productos_model->check_product($producto);
		if($this->session->userdata('status')=='administrator'){
			$data['message']="Si desea ingresar a la<br> página de administrador <br>haga click <a class='enlace' href='http://localhost/tarea3grupo4/index.php/admin' >aquí</a>.";
			$this->load->view('menu_view',$data);
			$this->load->view('detalle_view',$data);
		}
		else{
			$data['message']="";
			$this->load->view('menu_view',$data);
			$this->load->view('detalle_view',$data);
		}
		
	}
		
}