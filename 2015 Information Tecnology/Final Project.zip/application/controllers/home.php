<?php
class Home extends CI_Controller{
	
	public function __construct(){
        parent::__construct();
        $this->load->helper('form');
		$this->load->helper('url');
		$this->load->library('session');
		$this->load->database();
		$this->load->model('users_model');
		$this->load->model('productos_model');
		$this->load->model('ventas_model');
		
		$view_info = array();
	}
	
	
	function index(){
		#Vemos si el usuario no esta baneado, es decir o esta activo o es adm.
		if($this->session->userdata('status')=='active'OR$this->session->userdata('status')=='administrator' ){		
			#Recuperamos la informacion del usuario a traves de las variables de sesion.
			$id=$this->session->userdata('iduser');
			$datos=$this->users_model->recoger_datos($id);	
			$iduser = $this->session->userdata('iduser');
			#Aqui actualizamos el ultimo inicio de sesion del usuario.
			$last_login=$this->session->userdata('last_login');
			$datetime1=new DateTime($last_login);
			$datetime2=new DateTime('now');
			$diferencia=date_diff($datetime1,$datetime2);
			$dif=$diferencia->format("%m");
			$datos['dif']=$dif;
			if($this->session->userdata('status')=='administrator'){
			$view_info['message']="Si desea ingresar a la<br> página de administrador <br>haga click <a class='enlace' href='http://localhost/tarea3grupo4/index.php/admin' >aquí</a>.";
			}
			else{ $view_info['message']= "";
			}
			if($this->session->userdata('sex')=='femenino'){
				$datos['saludo']='Sra.';
			}
			else{$datos['saludo']='Sr.';}
			#Ahora debemos encontrar los productos sugeridos para este usuario. Esto se hace de la siguiente forma: los productos sugeridos corresponden  a todos los productos de la BD que sean de la misma talla que el ultimo articulo comprado por el usuario.
			#Aqui obtenemos las compras del usuario activo.
			$productos_comprados_user = $this->ventas_model->check_venta($iduser);
			#Obtenemos el ultimo producto comprado por el usuario.
			if(count($productos_comprados_user)>0){
				$ultimo_producto_comprado = $productos_comprados_user[count($productos_comprados_user)-1];
				#Ahora queremos la informacion de ese ultimo producto comprado para obtener la talla de este y poder generar sugerencias correspondientes.
				$ultimo_producto_comprado_info = $this->productos_model->check_product_id($ultimo_producto_comprado['idproduct']);
				#Ahora con la talla del ultimo producto comprado, seleccionamos todos los productos de la BD que tengan esa misma talla.
				$productos_sugeridos = $this->productos_model->product_similar($ultimo_producto_comprado_info['size']);
				$view_info['productos_sugeridos'] = $productos_sugeridos;
			}
			else{
				$view_info['productos_sugeridos'] = null;
			}
			$this->load->view('menu_view',$view_info);
			$this->load->view('home_view',$datos);
		}
		#Si el usuario esta banneado lo redirigimos al login.
		if($this->session->userdata('status')=='banned'){
			redirect('/login','refresh');
		}
		
	}
}