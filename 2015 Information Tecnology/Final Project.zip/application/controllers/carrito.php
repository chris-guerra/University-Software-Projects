<?php
class Carrito extends CI_Controller{
	
	public function __construct(){
        parent::__construct();
        $this->load->helper('form');
		$this->load->helper('url');
		$this->load->library('session');
		$this->load->database();
		$this->load->model('users_model');
		$this->load->model('productos_model');
		$this->load->model('ventas_model');
		
		$view_info = array();

	}
	
	function index(){
		#Chequeamos que este logeado, si no lo esta lo redirigimos al login.
		if($this->session->userdata('usuario') != TRUE){
			redirect('/login','refresh');
		}
		else{
			#Si esta logeado entonces cargamos todos los productos del carrito para mostrar en la pagina.
			$data['row_productos'] = $this->session->userdata('carrito');
			#Si es adm.
			if($this->session->userdata('status')=='administrator'){
				$data['message']="Si desea ingresar a la<br> página de administrador <br>haga click <a class='enlace' href='http://localhost/tarea3grupo4/index.php/admin' >aquí</a>.";
				$this->load->view('menu_view',$data);
				$this->load->view('carrito_view',$data);
			}
			#Si no.
			else{
				$data['message']="";
				$this->load->view('menu_view',$data);
				$this->load->view('carrito_view',$data);
			}
		}
	}
	#Agregar un producto desde su pagina de detalle al carrito del usuario.
	function agregar_carro(){
		$carrito = $this->session->userdata('carrito');
		#Primero debemos ver si el producto que se intenta agregar existe ya en el carro.
		$existe_en_carro = 0;
		#Recorremos todos los productos del carrito y vemos si alguno es igual al que se intenta agregar.
		#existe_en_carro = 0 => el producto no esta en el carro.
		#existe_en_carro = 1 => Si esta en el carro.
		foreach($carrito as $producto){
			if ($producto['item'] == $_POST['producto']){
				$existe_en_carro = 1;
			}
		}
		#Si no esta en el carro entonces lo agregamos.
		if($existe_en_carro == 0){
			#Buscamos la informacion del producto para agregarla al carro.
			$producto_agregar = $this->productos_model->check_product($_POST['producto']);
			#Nuestro carrito es un arreglo que contiene arreglos, donde cada uno de estos arreglos es un producto. 
			$producto = array('item' => $_POST['producto'], 'comment' => $producto_agregar['comment'],'picture' => $producto_agregar['picture'], 'price' => $producto_agregar['price'],'amount' => $producto_agregar['amount'],'idproduct' => $producto_agregar['idcart']);
			#Agregamos el arreglo producto al arreglo de arreglos carrito.
			array_push($carrito,$producto);
			#Sobre escribimos el carrito en las variables de sesion, pues ahora se le agrego algo.
			$this->session->set_userdata('carrito', $carrito);
		}
		#Despues de terminar todo, redirigimos al carrito.
		redirect('/carrito','refresh');
	}
	#Elimina algun producto del carro desde la pagina del carrito.
	function eliminar_carro(){
		#Cargamos el carrito de las variables de sesion.
		$carrito = $this->session->userdata('carrito');
		#Obtenemos la informacion del producto a eliminar, pues en el carrito no se tiene toda.
		$producto_eliminar = $this->productos_model->check_product($_POST['producto']);
		#Buscamos en el carrito el producto que buscamos para eliminarlo. 
		$i=0;
		while($i<count($carrito)){
			#Si el elemento del carrito coincide con el que se desea eliminar entonces hacemos ese campo igual a null.
			#Esto por que no supimos como borrar algo del arreglo sin que se desordene.
			if($carrito[$i]['item']==$producto_eliminar['item']){
				$carrito[$i] = null;
			}
			$i=$i+1;
		}
		#Dado que modificamos el carrito lo volvemos a escribir en las variables de sesion.
		$this->session->set_userdata('carrito', $carrito);
		#Una vez listo, redirigimos al carrito.
		redirect('/carrito','refresh');
	}
	#Nos muestra la vista de la pagina de check out, donde el usuario puede completar su compra.
	function check_out(){
		#Cargamos el saldo de las variables de sesion para mostrarlo en la pagina.
		$id=$this->session->userdata('iduser');
		$data['info']=$this->users_model->recoger_datos($id);
		$data['saldo']=$data['info']['saldo'];		
		#Cargamos el carrito del mismo modo y con el mismo proposito.
		$data['row_productos'] = $this->session->userdata('carrito');
		$data['message2'] = '';
		if($this->session->userdata('status')=='administrator'){
			$data['message']="Si desea ingresar a la<br> página de administrador <br>haga click <a class='enlace' href='http://localhost/tarea3grupo4/index.php/admin' >aquí</a>.";
			$this->load->view('menu_view',$data);
			$this->load->view('check_out_view',$data);
		}
		else{
			$data['message']="";
			$this->load->view('menu_view',$data);
			$this->load->view('check_out_view',$data);
		}
		
	}
	#Ejecuta una venta
	function venta(){
		#Obtenemos el saldo, el nombre de usuario y el id de usuario desde las variables de sesion.
		$iduser=$this->session->userdata('iduser');
		$data['info']=$this->users_model->recoger_datos($iduser);
		$saldo_cliente=$data['info']['saldo'];	
		$user = $data['info']['username'];
		#Total es el monto sumado de todos los productos a comprar en el carrito.
		$total = $_POST['total'];
		#Para que la venta sea posible el saldo del cliente debe ser al menos igual al total. 
		#Ademas, si el total es igual a cero significa que el carrito esta vacio, en cuyo caso no efectuamos ninguna venta.
		if($saldo_cliente >= $total && $total!=0){
			#Si se efectua la venta modificamos el saldo del cliente en las variables de sesion y en la BD.
			$this->session->set_userdata('saldo', $saldo_cliente - $total);
			$this->users_model->update_saldo($user,$saldo_cliente - $total);
			#Ahora debemos descontar el stock de cada producto en el carrito y ademas debemos vaciar este.
			$i=0;
			$carrito = $this->session->userdata('carrito');
			#Recorremos el carrito.
			while($i<count($carrito)){
				#Se puede dar que el carrito tenga valores null, porque cuando se queria eliminar un producto, en vez de eliminarlo se dejaba su campo como null.
				if($carrito[$i]!=null){
					#Si es que el campo es distinto de null entonces debemos registrar la venta en la BD y descontar el stock.
					$this->productos_model->modify_product_amount($carrito[$i]['item'],$carrito[$i]['amount']-1);
					$this->ventas_model->new_venta($iduser,$carrito[$i]['idproduct']);
				}
				$i=$i+1;
			}
			#Redefinimos el carrito para que este vacio.
			$carrito = array();
			#Updateamos la variable de sesion correpondiente al carrito.
			$this->session->set_userdata('carrito', $carrito);
			$data['message2'] = 'Gracias por su compra';
		}
		#Si no entra en el primer if puede deberse a que el carro esta vacio o que el saldo del cliente es insuficiente.
		else{
			if($total == 0){
				$data['message2'] = 'Carro vacio';
			}
			else{
				$data['message2'] = 'Lo sentimos, su saldo es insuficiente';
			}
		}
		#De cualquier manera ahora tenemos un nuevo saldo, pues debemos descontar el costo de la compra. 
		$data['saldo'] =  $this->session->userdata('saldo');
		#Ahora volvemos al checkout, para esto debemos entregar las variables que pide la vista.
		#Row productos contiene todos los productos del carrito, despues de una venta este se encuentra vacio.
		$data['row_productos'] = $this->session->userdata('carrito');
		if($this->session->userdata('status')=='administrator'){
			$data['message']="Si desea ingresar a la<br> página de administrador <br>haga click <a class='enlace' href='http://localhost/tarea3grupo4/index.php/admin' >aquí</a>.";
			$this->load->view('menu_view',$data);
			$this->load->view('check_out_view',$data);
		}
		else{
			$data['message']="";
			$this->load->view('menu_view',$data);
			$this->load->view('check_out_view',$data);
		}
		
	}
		
}