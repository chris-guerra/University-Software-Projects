<?php
class Perfil extends CI_Controller{
	
	public function __construct()
       {
        parent::__construct();
        $this->load->helper('form');
		$this->load->helper('url');
		$this->load->library('session');
		$this->load->database();
		$this->load->model('users_model');
		$data=array();
		$view_info = array();
	}
	
	function index(){
		#Cargamos toda la info. del usuario en sesion.
		$data['sesion'] = $this->session->all_userdata();
		$id=$this->session->userdata('iduser');
		$data['info']=$this->users_model->recoger_datos($id);
		$data['saldo']=$data['info']['saldo'];
		#Guardamos el usuario "antiguo" por si este desea cambiarlo, para poder tener una referencia de que cambiar en la BD.
		$usuarioantiguo=$data['info']['username'];
		#Si el usuario no esta logeado lo redirigimos al login.
		if($this->session->userdata('usuario') != TRUE){
			redirect('/login','refresh');
		}
		else{
			#Caso contrario, el usuario si esta logeado y procedemos.
			if($this->session->userdata('status')=='administrator'){
				$data['message']="Si desea ingresar a la<br> página de administrador <br>haga click <a class='enlace' href='http://localhost/tarea3grupo4/index.php/admin' >aquí</a>.";
			}
			else{$data['message']="";
			}
		}		
		#Aqui revisamos que todos los campos del form para editar info del usuario esten seteados y no contengan solo espacios vacios.	
		if(isset($_POST['nombre2'])&&isset($_POST['usuario2'])&&isset($_POST['contrasena2'])&&isset($_POST['apellido2'])&&($_FILES['avatar2']['size'] > 0)&&isset($_POST['correo2'])&&$_POST['nombre2']!=''&&$_POST['usuario2']!=''&&$_POST['contrasena2']!=''&&$_POST['apellido2']!=''&&$_POST['correo2']!=''){
			#Primero verificamos si el usuario quiere cambiar su nombre, es decir ingresa algo en el post usuario2 distinto de su nombre de usuario actual.
			$user=$_POST['usuario2'];
			#user_exists verifica esto en la BD. De no estar el nombre disponible se le informa al usuario con un mensaje.
			if($this->users_model->user_exists($user) != null && $user!=$data['info']['username']){
				$data['message2']="Nombre de usuario no disponible.";
				$this->load->view('menu_view',$data);
				$this->load->view('perfil_view',$data);
			}
			#Si no, significa que el nombre de usuario si esta disponible y procedemos.
			else{
				#Primero cargamos la foto. Esta receta de codeigniter fue sacado de: http://www.formget.com/codeigniter-upload-image/
				$data['message2']='';
				$path = $_FILES['avatar2']['name'];
				$ext = pathinfo($path, PATHINFO_EXTENSION);
				//Seteamos las configuraciones deseadas para la carga de la imagen.
				$config['upload_path'] = './uploads/';
				$config['allowed_types'] = 'gif|jpg|png';
				$config['file_name'] = $user;
				$config['max_size'] = 1000;
				$config['max_width'] = 1000;
				$config['max_height'] = 1000;
				//Ahora sobre escribimos la imagen antigua.
				$config['overwrite'] = TRUE;
 				$this->load->library('upload', $config);
				$this->upload->initialize($config);
				$this->upload->set_allowed_types('*');
				#Si la imagen es subida con exito entonces hacemos los demas cambios pertinentes en la BD.
				if($this->upload->do_upload('avatar2')){
					$this->users_model->update_user($usuarioantiguo,$_POST['nombre2'],$_POST['apellido2'],$_POST['sexo2'],$user.".".$ext,$_POST['correo2'],$_POST['usuario2'],$_POST['contrasena2']);
					$data['info']=$this->users_model->recoger_datos($id);
					$this->load->view('menu_view',$data);
					$data['message2']="Datos Modificados con éxito";
					$this->load->view('perfil_view',$data);
					
				}
				#Si no, mostramos el error correspondiente. Codeigniter provee de una instruccion para mostrar los errores al hacer un upload.
				else{
					$data['message2']= $this->upload->display_errors();
					echo $this->upload->display_errors();
					$this->load->view('menu_view',$data);
					$this->load->view('perfil_view',$data);
				}
			}
		}
		#Aqui agarramos el caso en que las casillas no estan todas rellenadas.
		else{
			$data['message2']="Para actualizar los datos se deben llenar todas las casillas";
			$this->load->view('menu_view',$data);
			$this->load->view('perfil_view',$data);
		}
	}
	#Se encarga de agregar saldo al usuario. Modifica la variable de sesion y la BD.
	function add_saldo(){
		$id=$this->session->userdata('iduser');
		$data['info']=$this->users_model->recoger_datos($id);
		$nuevo_saldo = $_POST['saldo'];
		$this->users_model->update_saldo($data['info']['username'],$nuevo_saldo);
		redirect('/perfil','refresh');
	}
}
?>