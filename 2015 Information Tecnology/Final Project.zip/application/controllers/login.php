<?php
class Login extends CI_Controller{
	
	public function __construct()
       {
        parent::__construct();
        $this->load->helper('form');
		$this->load->helper('url');
		$this->load->library('session');
		$this->load->database();
		$this->load->model('users_model');
		
		$view_info = array();
	}
	
	function index(){
		#Obtenemos toda la info. de sesion del usuario.
		$data = $this->session->all_userdata(); 
		#Si la sesion no esta iniciada entonces esto es igual a FALSE.
		if($this->session->userdata('usuario') != FALSE){
			#Al ingresar actualizamos la fecha del ultimo ingreso de sesion.
			$this->users_model->update_lastlog($data['usuario'],$data['last_login']);
			#Redirigimos al home.
			redirect('/home','referesh');
			
		}
		#Si el usuario no ha iniciado sesion la devolvemos al login.
		else{
			$view_info['message'] = "";
			$this->load->view('login_view',$view_info);
		}	
	}
	#Chequea que el user y pass ingresados en el login sean correctos, de serlos, inicializa la sesion con las variables correspondientes.
	function check_login(){
		$user = $_POST['usuario'];
		$pass = $_POST['contrasena'];

		$resultado = $this->users_model->check_user($user,$pass);
		#Si resultado es distinto de null significa que en la BD existe un registro con ese user y esa pass.
		if ($resultado != null){
			#Estan son todas las variables de sesion que utilizaremos.
			$carrito = array();
			$sess_var = array(
                   'usuario' => $resultado['username'],
                   'pass' => $resultado['password'],
                   'nombre' => $resultado['name'],
                   'apellido' => $resultado['last_name'],
                   'user' => $resultado['username'],
				   'sex' => $resultado['sex'],
				   'correo' => $resultado['email'],
				   'status' => $resultado['status'],
				   'last_login' => $resultado['last_login'],
				   'login_medio' => $resultado['middle_login'],
				   'avatar' => $resultado['avatar'],
			   	   'saldo' => $resultado['saldo'],
			   	   'carrito' => $carrito,
			   	   'iduser' => $resultado['idusers']);
			#Se setean las variables de sesion con la funcion set_userdata propia de codeigniter.
			$this->session->set_userdata($sess_var);
			if($resultado['status'] == "banned"){
				#View info va a contener todos mensajes que queremos mostrar en la vista.
				$view_info['message'] = "<br>Este usuario ha sido bloqueado de la página. <br>No podrá volver a ingresar a ella.";
				$this->load->view('login_view',$view_info);
				$this->session->sess_destroy();
			}
			#else si el usuario esta bien logeado y no esta banneado
			else{
				#Redirigimos al controlador mismo, como nose especifica funcion se ejecuta el index.
				redirect('/login','refresh');
				
			}
		}
		#Si es que no hay coincidencias de user y pass, entonces mostramos el mensaje correspondiente.
		else{
			$view_info['message'] = "<br>Usuario y/o contraseña incorrectos, inténtelo nuevamente. O bien, regístrese.";
			$this->load->view('login_view',$view_info);
		}
	}
	function log_out(){
		//Terminamos la sesion y redirigimos a la pagina de login.
		$this->session->sess_destroy();
		$view_info['message'] = '';
		$this->load->view('login_view',$view_info);
	}
}

?>