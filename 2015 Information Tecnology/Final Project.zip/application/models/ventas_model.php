<?php
	class Ventas_model extends CI_Model {

    function __construct(){
        // Call the Model constructor
        parent::__construct();
    }
  
	#Selecciona todas las ventas de la BD.
	function get_venta(){
		$sql="SELECT * FROM venta ";
		$qry = $this->db->query($sql);
		$resultado = $qry->result_array();
		return $resultado;
   	}
	#Nos entrega todas las ventas relacionadas con un usuario.
	function check_venta($iduser){
		$sql="SELECT * FROM venta WHERE iduser='".$iduser."'";
		$qry = $this->db->query($sql);
		$resultado = $qry->result_array();
		return $resultado;
   	}
   	#Guarda un nueva venta en la BD.
	function new_venta($iduser , $idproduct){
		$variables=array(
		'iduser'=>$iduser,
		'idproduct'=>$idproduct
		);
		$this->db->insert('venta',$variables);
		
	}
}

?>