<?php
	class Productos_model extends CI_Model {

    function __construct(){
        // Call the Model constructor
        parent::__construct();
    }
  
	#Selecciona todos los productos de la BD.
	function get_product(){
		$sql="SELECT * FROM product ";
		$qry = $this->db->query($sql);
		$resultado = $qry->result_array();
		if($resultado!=null){
			return $resultado;
        }
        else{
        	return null;
        }
   	}
	#Selecciona un producto de la BD, identificadolo por su item.
	function check_product($product){
		$sql="SELECT * FROM product WHERE item='".$product."'";
		$qry = $this->db->query($sql);
		$resultado = $qry->row_array();
		return $resultado;
   	}
	#Equivalente a la anterior, solo que utiliza otra columna para identificar el producto.
	#Selecciona un producto de la BD, identificandolo por su idcart.
	function check_product_id($idproduct){
		$sql="SELECT * FROM product WHERE idcart='".$idproduct."'";
		$qry = $this->db->query($sql);
		$resultado = $qry->row_array();
		return $resultado;
   	}
	#Retorna todos los productos que tienen la talla especificada.
	function product_similar($size){
		$sql="SELECT * FROM product WHERE size='".$size."'";
		$qry = $this->db->query($sql);
		$resultado = $qry->result_array();
		return $resultado;	
	}
   	#Guarda un producto nuevo en la BD.
	function save_product($item , $price , $amount, $picture, $size, $comment){
		$variables=array(
		'item'=>$item,
		'price'=>$price,
		'amount'=>$amount,
		'picture'=>$picture,
		'size'=>$size,
		'comment'=>$comment
		);
		$this->db->insert('product',$variables);
		
	}
	#Modifica el precio de un producto, identificandolo por su item.
	function modify_product_price($producto,$price){
		$variables=array('price' => $price);
		$this->db->where('item',$producto);
		$this->db->update('product',$variables);
	}
	#idem, pero con la cantidad o stock.
	function modify_product_amount($producto,$amount){
		$variables=array('amount' => $amount);
		$this->db->where('item',$producto);
		$this->db->update('product',$variables);
	}
	#idem, con la foto. 
	function modify_product_picture($producto,$picture){
		$variables=array('picture' => $picture);
		$this->db->where('item',$producto);
		$this->db->update('product',$variables);
	}
	#Idem, talla.
	function modify_product_size($producto,$size){
		$variables=array('size' => $size);
		$this->db->where('item',$producto);
		$this->db->update('product',$variables);
	}
	#Idem, comentario.
	function modify_product_comment($producto,$comment){
		$variables=array('comment' => $comment);
		$this->db->where('item',$producto);
		$this->db->update('product',$variables);
	}
}

?>