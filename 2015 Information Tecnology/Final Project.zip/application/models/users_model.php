<?php
	class Users_model extends CI_Model {

    function __construct(){
        // Call the Model constructor
        parent::__construct();
    }
    #Chequea si existe usuario con ese nombre de user y pass, de exisistirlo, lo retorna.
    function check_user($user,$pass){
    	//Si el resultado retornado es nulo, entonces el user y pass ingresados no coinciden.
		$sql="SELECT * FROM users WHERE username='".$user."' AND password='".$pass."' ";
		$qry = $this->db->query($sql);
		$resultado = $qry->row_array();
		if($resultado!=null){
			return $resultado;
        }
        else{
        	return null;
        }
   	}
   	#Actualiza la fecha de ultimo ingreso.
    function update_lastlog($user,$last_login){
    	$middle_log = array('middle_login' => $last_login);
    	$this->db->where('username',$user);
    	$this->db->update('users',$middle_log);
    	
    	$lastlog = date("Y-m-d");
    	$new_date = array('last_login' => $lastlog);
    	
    	$this->db->where('username',$user);
    	$this->db->update('users',$new_date);
    }
	#Verifica si existe un usuario con este nombre de usuario, de exisistirlo retorna su info. 
	#Hace lo mismo que la primera >.<
	function user_exists($user){
		$sql="SELECT * FROM users WHERE username='".$user."'";
		$qry = $this->db->query($sql);
		$resultado = $qry->row_array();
		return $resultado;
	}
	#Guarda un usuario nuevo en la BD.
	function save_user($nombre,$apellido,$sexo,$avatar,$correo,$nombreusuario,$contrasena){
		$variables=array(
		'name'=>$nombre,
		'last_name'=>$apellido,
		'sex'=>$sexo,
		'avatar'=>$avatar,
		'email'=>$correo,
		'username'=>$nombreusuario,
		'password'=>$contrasena,
		'status'=>'active',
		'first_login'=>date("Y-m-d"),
		'middle_login'=>NULL,
		'last_login'=>date("Y-m-d")
		);
		$this->db->insert('users',$variables);
		
	}
	#Cambia el estado del usuario, de banned,activo o adm.
	function update_status($user,$status){
		$variables=array('username' => $user,
			'status' => $status);
		$this->db->where('username',$user);
		$this->db->update('users',$variables);
	}
	#Cambia el saldo del usuario de la BD.
	function update_saldo($user,$new_saldo){
		$variables=array('saldo' => $new_saldo);
		$this->db->where('username',$user);
		$this->db->update('users',$variables);
	}
	#Borra un usuario de la BD.
	function delete_user($user){
		$sql="DELETE FROM users WHERE username='".$user."'";
		$this->db->query($sql);
	}
	#Actualiza informacion de un usuario en la BD.
	function update_user($user,$nombre,$apellido,$sexo,$avatar,$correo,$nombreusuario,$contrasena){
		$datosn = array(
		'name'=>$nombre,
		'last_name'=>$apellido,
		'sex'=>$sexo,
		'avatar'=>$avatar,
		'email'=>$correo,
		'username'=>$nombreusuario,
		'password'=>$contrasena,
		);
		$this->db->where('username',$user);
    	$this->db->update('users',$datosn);


		}
	#Hace lo mismo que las otras >.<
    function check_username($user){
		$sql="SELECT * FROM users WHERE username='".$user."'";
		$qry = $this->db->query($sql);
		$resultado = $qry->row_array();
		if($resultado!=null){
			return $resultado;
        }
        else{
        	return null;
        }
   	}
	
	function recoger_datos($id){
		$sql="SELECT * FROM users WHERE idusers='".$id."'";
		$qry = $this->db->query($sql);
		$resultado = $qry->row_array();
		if($resultado!=null){
			return $resultado;
        }
        else{
        	return null;
        }
   	}
}

?>