<html>
<head>
<meta charset="UTF-8">
    <style type="text/css">
		body {
			color: #787878;
			background-color: white}

		h2{
			font-family: Helvetica, Geneva, Arial,
				SunSans-Regular, sans-serif }
		div.bloque1{
			margin-bottom:2em;
			background-color: #50BB7F}
			
		div.logo{
			background-color:white}		
			
		table.bloques a{
			text-decoration: none;
			color: white;
			}
			
		table.bloques td{
			background-color:#50BB7F;
			padding: 1em;
			padding-left:2em;
			padding-bottom:0.0001em;
			}
			
		div.texto{
			background-color:white;

			}
		#texto{
			width:300px;
			height:100px;
			}
		#espacio{
			width:100px;
			height:100px;
			}
		a.enlace:hover{
			text-decoration: none;
			color:#FF5930}	
  </style>
</head>
<body>
	<table align="center">
		<tr>
			<td>
				<?php
					#if($_SESSION['status']=='administrator'){
						echo $message;
					#s}
				
				?>
			</td>

			<td>
				<div align="center" class="logo">
				<img src="http://localhost/tarea3grupo4/imagenes/logo.png" height="150" width="248" />
				</div>
			</td>
			<td>
 				<div align="right" class="bloque0" >
				<h4><font color="#787878"> <a class="enlace" href="<?= base_url();?>index.php/carrito" >Tu Carro <img src="http://localhost/tarea3grupo4/imagenes/carrito.png" height="20" width="20" />   </h4></a>
				<form action="<?= base_url();?>index.php/login/log_out" method="POST">
				<input type="submit" value="Cerrar Sesión" />
				</form>
				</div>
			</td>

		</tr>
	</table>
<div align="center" class="bloque1">
		<table class="bloques">
			<tr>
				<td>
					<a class="enlace" href="<?= base_url();?>index.php/home" ><h2> Inicio <h2></a>
				</td>
				<td>
					<a class="enlace" href="<?= base_url();?>index.php/catalogo" ><h2> Catalogo <h2></a>
				</td>
				<td>
					<a class="enlace" href="<?= base_url();?>index.php/quienessomos" ><h2> Quienes Somos </h2></a>
				</td>
				<td>
					<a class="enlace" href="<?= base_url();?>index.php/perfil"><h2> Perfil </h2></a>
				</td>
			</tr>
		</table>
</div>
</html>