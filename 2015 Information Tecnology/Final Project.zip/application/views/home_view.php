<?php 
#include_once('./funciones/fun_general.php');
?>

<html>
<head>
	<meta charset="UTF-8">
  <title>D'kids</title>
   
</head>
	<?php
	#if(!isset($_SESSION['usuario'])&&!isset($_SESSION['contrasena'])){
	#	header("location: ./index2.php"); //redirigir a index
	#	exit();
	#} ?>
	
<body>

	

	<!-- página -->
		
	<div align="center" class="logo">
		<table>
			<td>
				<tr>
					<?php
					echo "¡$saludo $name $last_name!, bienvenido a nuestra página. Han pasado $dif días desde su última visita<br><br>
					En nuestra página encontrará varias secciones. Para saber mas sobre nosotros ingrese a la sección <a class='enlace' href='http://localhost/tarea3grupo4/index.php/quienessomos' >Quienes somos</a>.<br>
					Para conocer nuestros productos, puedes ingresar a la sección de <a class='enlace'href='http://localhost/tarea3grupo4/index.php/catalogo' >Catálogo</a>. En <a class='enlace'href='http://localhost/tarea3grupo4/index.php/perfil' >Perfil</a>, podrás revisar tu cuenta y datos";
					?> 
				</tr>
				
				<tr>
					<!--- ><img src="http://localhost/tarea3grupo4/imagenes/imagen_portada.jpg" height="600" width="960" /> ---->
					<h3 align="center"> Algunos productos sugeridos para ti: </h3>
					<table class="catalogo">
							<?php
							#Productos sugeridos en un arreglo de arreglos, dodne cada uno corresponde a un producto sugerido. Notamos que solo mostramos como productos sugeridos aquellos que tengan stock no negativo.
							if($productos_sugeridos != null){
								foreach($productos_sugeridos as $producto){
									if($producto['amount']>0){
										$producto_tabla = 
												"<tr>
													<td>
														<a href='' ><img src='http://localhost/tarea3grupo4/product_img/".$producto['picture']."' height=300px width=250px /></a>
													</td>
													<td class= 'desc' align='center'>
														".$producto['comment']."
														<form action='catalogo/ver_detalle' method='POST'><input type='hidden' name='producto' value=".$producto['item']."><input type='submit' value=Detalle></form>
													</td>
												</tr>
												";
										echo $producto_tabla;
									}
								}
							}
							?>
					</table>
				</tr>
			</td>
		</table>
	</div>
	
</body>
</html>

