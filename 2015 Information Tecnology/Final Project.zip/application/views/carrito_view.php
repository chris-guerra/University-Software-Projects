
<html>
<head>
<meta charset="UTF-8">
  <title>Catalogo</title>
    <style type="text/css">
		

		body {
			color:  #787878;
			background-color: white}
		

		h2{
			font-family: Helvetica, Geneva, Arial,
				SunSans-Regular, sans-serif }
		
		div.bloque1{
			margin-bottom:2em;
			background-color:#50BB7F}
			
		div.logo{
			background-color:white}		
		
		table.bloques a{
			text-decoration: none;
			color: white;
			}
		
		table.bloques td{
			background-color:#50BB7F;
			padding: 1em;
			padding-left:2em;
			padding-bottom:0.0001em;
			}
			
		table.catalogo{
			font-family: Helvetica, Geneva, Arial,
					SunSans-Regular, sans-serif
			}
		
		td.desc{
			background-color:#FF5930;
			color: white}
		td.desc a{
			text-decoration: none;
			color: white;
			}
		a.enlace:hover{
			text-decoration: none;
			color:#FF5930}
		
			
  </style>

</head>
	<?php
	#session_start();
	#if(!isset($_SESSION['usuario'])){
	#	session_destroy();
	#	header("location: ./index2.php"); //redirigir a index
	#	exit();
	#if(!isset($_SESSION['usuario'])){
	#	header("location: ./index2.php"); //redirigir a index
	#	exit();
	#} ?>
<body>
		
	<div align="center" class="logo">
		<h2>Tu Carro</h2>
		<table class="catalogo">
				<?php
				#Row productos es un arreglo de arreglos, donde cada uno de sus arreglos constituyentes es un producto. Es decir row, es un producto dentro del carrito.
				if($row_productos != null){
					foreach($row_productos as $row){
						if($row!=null){
								$producto_tabla = 
										"<tr>
											<td>
												<a href='' ><img src='http://localhost/tarea3grupo4/product_img/".$row['picture']."' height=300px width=250px /></a>
											</td>
											<td class= 'desc' align='center'>
												".$row['comment']." </br>
												$ ".$row['price']."
												<form action='carrito/eliminar_carro' method='POST'><input type='hidden' name='producto' value=".$row['item']."><input type='submit' value=Eliminar></form>
											</td>
										</tr>
										";
								echo $producto_tabla;
						}
					}
				}
				?>
		</table>
		
		<form action="<?= base_url();?>index.php/carrito/check_out" method="POST">
		<input type="submit" value="Ir al Check-out" />
	</div>
</body>
</html>
