	<?php 
	#session_start(); 
	#include_once ('./funciones/fun_admin.php');
	#include_once ('./funciones/vender_productos.php');
	?>
<html>
<head>
  <title>D'kids</title>
  <meta charset="UTF-8">
</head>

<body>
<!-- Header -->



<!-- página -->
	<div class="info_basica">
		<table align="center">
	<!--lado izquierdo-->
			<tr>
				<td>
					<!--formulario para agregar productos-->
					<form action="<?= base_url();?>index.php/admin/agregar_productos" method="POST" align="center" enctype="multipart/form-data">
						<h3>Producto a agregar:</h3>
						<br>
						<input type="text" name="producto" placeholder="Nombre de Producto"/>
						<br>
						<input type="text" name="precio" placeholder="Precio ej: 7000"/>
						<br>
						<input type="text" name="cantidad" placeholder="Cantidad ej: 5"/>
						<br>
						<input type="file" class="file" data-show-preview="false" name="imagen2" placeholder="Imagen de Producto"/>
						<br>
						<input type="text" name="talla" placeholder="Talla. ej: 3M - 6M"/>
						<br>
						<textarea rows="10" cols="17.5" name="comentario" placeholder="Descripción Sobre el Producto"></textarea>
						<br>
						<input type="submit" value="Agregar"/>
						<br>
					</form>
				</td>
				<!--lado derecho-->
				<td>
					<form action="<?= base_url();?>index.php/admin/estado_usuario" method="POST" align="center">
						<h3>Ingrese el usuario a regular:</h3>
						<input type="text" name="usuario3" placeholder="Nombre de Usuario"/>
						<br>
						<input type="radio" name="status" value="active"/> Activo
						<input type="radio" name="status" value="banned"/> Baneado
						<br>
						<input type="radio" name="status" value="administrator"/> Admin.
						<input type="radio" name="status" value="borrar"/> Eliminar
						<br>
						<input type="submit" value="Modificar"/>
						<br>
						<?php
						#
						#//aqui se hace un echo notificando el cambio echo por el usuario
						#estado_usuario();
						?>
					</form>
					<?php echo $message_adm; ?>
				</td>
				<td>
					<!--formulario para modificar un producto-->
					<form action="<?= base_url();?>index.php/admin/modificar_producto" method="POST" align="center" enctype="multipart/form-data">
						<h3>Producto a editar:</h3>
						<br> Si desea editar un producto
						<br>ingrese el nombre de uno que
						<br>ya existe y modifique las
						<br>casillas que desea cambiar.
						<br>
						<input type="text" name="producto2" placeholder="Nombre de Producto"/>
						<br>
						<input type="text" name="precio2" placeholder="Precio ej: 7000"/>
						<br>
						<input type="text" name="cantidad2" placeholder="Cantidad ej: 5"/>
						<br>
						<input type="file" class="file" data-show-preview="false" name="imagen3" placeholder="Imagen de Producto"/>
						<br>
						<input type="text" name="talla2" placeholder="Talla. ej: 3M - 6M"/>
						<br>
						<textarea rows="10" cols="17.5" name="comentario2" placeholder="Descripción Sobre el Producto"></textarea>
						<br>
						<input type="submit" value="Editar"/>
						<br>
						<?php
						#aqui modificamos los productos y hacemos un echo notificando el cambio
						#modificar_productos();
						?>
					</form>
				</td>
			</tr>
		</table>
		<table align="center">
			<td align="center">
				<h3>VENTAS EN EL SISTEMA</h3>
			</td>
		</table>
		<table align="center">
			<thead>
				<tr>
					<th>Id Producto</th>
					<th>Id Usuario</th>
				</tr>
			</thead>
				<?php
				#Ventas es un arreglo de arreglos, donde cada uno de estos arreglos contiene una venta. Es decir, un id de producto y un id de usuario relacionados.
				if($ventas != null){
					foreach($ventas as $venta){
							$venta_tabla = 
									"<tr>
										<td class= 'desc' align='center'>
											".$venta['idproduct']."
										</td>
										<td class= 'desc' align='center'>
											".$venta['iduser']."
										</td>
									</tr>
									";
							echo $venta_tabla;
					}
				}
				?>
		</table>
	</div>	
</body>
</html>
