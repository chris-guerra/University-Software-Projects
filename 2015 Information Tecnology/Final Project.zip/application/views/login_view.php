<?php
#session_start();
?>
<html>
<head>
	<meta charset="UTF-8">
  <title>D'kids</title>
    <style type="text/css">
		body {
			color: #787878;
			background-color: white}

		h2{
			font-family: Helvetica, Geneva, Arial,
				SunSans-Regular, sans-serif }
		div.bloque1{
			margin-bottom:2em;
			background-color:#50BB7F}
			text-decoration: none;

			
		div.logo{
			background-color:white;
			#FFFAFA}
		
		table.bloques{
			color: #50BB7F;
			}
		
		table.bloques td{
			background-color:#50BB7F;
			padding: 1em;
			padding-left:2em;
			padding-bottom:0.0001em;
			}
			
  </style>
</head>
 	<?php
	#if(isset($_SESSION['usuario'])&&isset($_SESSION['pass'])){
	#	header("location: ./home.php"); //redirigir a home
	#	exit();
	#} ?>
<body>
<!-- Header -->
	<table align="center">
		<tr>
			<td>
				<div align="left" class="logo">
				<img src="http://localhost/tarea3grupo4/imagenes/logo.png" height="150" width="248" />
				</div>
			</td>
			<td>
 				<div align="right" class="bloque0" >
					<table>
						<tr>
							<td>
<!-- login -->
								<div align="left">
										
										<?php //casillas:
										//if(empty($_SESSION['usuario'])&&empty($_SESSION['contrasena'])){
										//	echo"<h4>Debes iniciar sesión para visitar nuestra página</h4>";
										//}
										?>
										<h4>Para acceder ingrese sus datos</h4>
										
										<form action="<?= base_url();?>index.php/login/check_login" method='POST'>
										Usuario:  <input type='text' name='usuario'/>
										<br>Contraseña:<input type='password' name='contrasena'/>
										<br><input type='submit' value='Ingresar' align='center'/>

										

										
										
										
										<br>Si no se ha registrado, hágalo <a href='http://localhost/tarea3grupo4/index.php/registro/' > aquí.</a>
										<?php echo $message ?>
									</form>

								</div>
							</td>
						</tr>
					</table>
				</div>
			</td>
		</tr>
	</table>
	<div align="center" class="bloque1">
		<table class="bloques">
			<tr>
				<td>
					<h2> Catálogo <h2>
				</td>
				<td>
					<h2> Quiénes Somos </h2>
				</td>
				<td>
					<h2> Perfil </h2>
				</td>
			</tr>
		</table>
	</div>
	<!-- página -->
		
	<div align="center" class="logo">
		<img src="http://localhost/tarea3grupo4/imagenes/imagen_portada.jpg" height="600" width="960" 
		/>
	</div>
</body>
</html>
