<html>
<head>
	<meta charset="UTF-8">
  <title>D'kids</title>
    <style type="text/css">
		body {
			color: #787878;
			background-color: white}

		h2{
			font-family: Helvetica, Geneva, Arial,
				SunSans-Regular, sans-serif }
		div.bloque1{
			margin-bottom:2em;
			background-color:#50BB7F}
			text-decoration: none;
		
		div.logo{
			background-color:white;
			#FFFAFA}
		
		table.bloques{
			color: #50BB7F;
			}
		
		table.bloques td{
			background-color:#50BB7F;
			padding: 1em;
			padding-left:2em;
			padding-bottom:0.0001em;
			}
			
  </style>

</head>


<body>
	<!-- Header -->
	<div align="center" class="logo">
		<img src="http://localhost/tarea3grupo4/imagenes/logo.png" height="150" width="248" />
	</div>
	<div align="center" class="bloque1">
		<table class="bloques">
			<tr>
				<td>
					<h2> Catálogo <h2>
				</td>
				<td>
					<h2> Quienes Somos </h2>
				</td>
				<td>
					<h2> Perfil </h2>
				</td>
			</tr>
		</table>
	</div>

	<!-- registrarse: -->
	<div align="center" class="formulario">
		<form action="<?= base_url();?>index.php/registro/new_user" method="POST" enctype="multipart/form-data">
			<h4> Complete los siguientes campos:</h4>
			<input type="text" name="nombre" placeholder="Nombre"/>
			<br>
			<input type="text" name="apellido" placeholder="Apellido"/>
			<br>
			<input type="radio" name="sexo" value="masculino" checked/> Masculino
			<input type="radio" name="sexo" value="femenino"/> Femenino
			<br>
			<input id="avatar" name="avatar" type="file" class="file" data-show-preview="false" placeholder="Adjunte su Avatar">
			<br>
			<input type="text" name="correo" placeholder="Correo Electrónico"/>
			<br>
			<input type="text" name="usuario" placeholder="Nombre de Usuario"/>
			<br>
			<input type="password" name="contrasena" placeholder="Contraseña"/>
			<br>
			<input type="submit" value="Registrese"/>
			<br><a class="enlace" href="<?= base_url();?>index.php/login" > Volver a login.</a>
		</form>
		<?php echo $message ?>

	</div>

</body>
</html>