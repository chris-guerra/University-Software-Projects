
<html>
<head>
<meta charset="UTF-8">
  <title>Check-Out</title>
    <style type="text/css">
		

		body {
			color:  #787878;
			background-color: white}
		

		h2{
			font-family: Helvetica, Geneva, Arial,
				SunSans-Regular, sans-serif }
		
		div.bloque1{
			margin-bottom:2em;
			background-color:#50BB7F}
			
		div.logo{
			background-color:white}		
		
		table.bloques a{
			text-decoration: none;
			color: white;
			}
		
		table.bloques td{
			background-color:#50BB7F;
			padding: 1em;
			padding-left:2em;
			padding-bottom:0.0001em;
			}
			
		table.catalogo{
			font-family: Helvetica, Geneva, Arial,
					SunSans-Regular, sans-serif
			}
		
		td.desc{
			background-color:#FF5930;
			color: white}
		td.desc a{
			text-decoration: none;
			color: white;
			}
		a.enlace:hover{
			text-decoration: none;
			color:#FF5930}
		
			
  </style>

</head>
	<?php
	#session_start();
	#if(!isset($_SESSION['usuario'])){
	#	session_destroy();
	#	header("location: ./index2.php"); //redirigir a index
	#	exit();
	#if(!isset($_SESSION['usuario'])){
	#	header("location: ./index2.php"); //redirigir a index
	#	exit();
	#} ?>
<body>
		
	<div align="center" class="logo">
		
		<table class="catalogo">
			<thead>
				<tr>
					<th>PRODUCTO</th>
					<th>PRECIO</th>
				</tr>
			</thead>
				<?php
				#Row productos en un arreglo de arreglos, ahora cada arreglo que lo constituye en un producto en el carrito, para ser mostrado en el checkout. La variable total guarda el total de la eventual venta.
				$total = 0;
				if($row_productos != null){
					foreach($row_productos as $row){
						$total = $total + $row['price'];
						$producto_tabla = 
								"<tr>
									<td class= 'desc' align='center'>
										 ".$row['comment']."
									</td>
									<td class= 'desc' align='center'>
										 ".$row['price']."
									</td>
								</tr>
								";
						echo $producto_tabla;
					}
				}
				?>
				
				<tr>
					<td class='desc' align='center'>
						TOTAL: $<?php echo $total;?>
					</td>
				</tr>
				<tr>
					<td class='desc' align='center'>
					TU SALDO ES: $ <?php echo $saldo;?>
					</td>
				</tr>
				<tr>
					<td class='desc' align='center'>
					<form action='venta' method='POST'><input type='hidden' name='total' value=<?php echo $total;?>><input type='submit' value=Comprar></form>
					</td>
				</tr>
				<tr>
					<td class='desc' align='center'>
					<?php echo $message2;?>
					</td>
				</tr>
				<tr>
		</table>
		
		
	</div>
</body>
</html>
