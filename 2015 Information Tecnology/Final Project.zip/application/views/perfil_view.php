<?php 
#include_once('./funciones/fun_general.php');
?>

<html>
<head>
	<meta charset="UTF-8">
  <title>D'kids</title>
   
</head>
	<?php
	#if(!isset($_SESSION['usuario'])&&!isset($_SESSION['contrasena'])){
	#	header("location: ./index2.php"); //redirigir a index
	#	exit();
	#} ?>
	
<body>
	<div align="center" class="info_basica">
		<table align="centered">
	<!--lado izquierdo-->
			<tr>
				<td>
					<h1>
					<?php
					echo '<h3 align="center">Sus datos:</h3>';
					//imagen 
					echo '<img src="/tarea3grupo4/uploads/'.$info['avatar'].'" height="150" width="150">';
					?>
				</td>
				<td>
				</h1>
				<?php

				echo '<i><strong>Nombre</strong></i>: '.$info['name'].'<br>';
				echo '<i><strong>Apellido</strong></i>: '.$info['last_name'].'<br>';
				echo '<i><strong>Usuario</strong></i>: '.$info['username'].'<br>';
				echo '<i><strong>Correo:</strong></i>'.' '.$info['email'].'<br>';
				echo '<i><strong>Sexo</strong></i>: '.$info['sex'].'<br>';
				echo '<i><strong>Saldo</strong></i>: '.$info['saldo'].'<br>';
				?>
				</td>
		<!--lado derecho-->
		<!--Falta hacer funcionaaaar-->
				<td>
					<form action="http://localhost/tarea3grupo4/index.php/perfil" method="POST" align="center" enctype="multipart/form-data">
						<h3>Modifique sus datos:</h3>
						<input type="text" name='nombre2' placeholder="Nombre"/>
						<br>
						<input type="text" name="apellido2" placeholder="Apellido"/>
						<br>
						<input type="radio" name="sexo2" value="masculino"/> Masculino
						<input type="radio" name="sexo2" value="femenino"/> Femenino
						<br>
						<input type="file" class="file" data-show-preview="false" name="avatar2" placeholder="Adjunte su Avatar"/>
						<br>
						<input type="text" name="correo2" placeholder="Correo Electrónico"/>
						<br>
						<input type="text" name="usuario2" placeholder="Nombre de Usuario"/>
						<br>
						<input type="password" name="contrasena2" placeholder="Contraseña"/>
						<br>
						<input type="submit" value="Modificar"/>

					</form>
					<?php echo $message2 ?>
				</td>
				<td>
					<form action="<?= base_url();?>index.php/perfil/add_saldo/" method="POST" align="center" enctype="multipart/form-data">
						<h3>Actualiza tu saldo:</h3>
						<input type="number" name='saldo' placeholder="Saldo"/>
						<br>
						<input type="submit" value="Actualizar"/>
					</form>
				</td>
			</tr>
		</table>
	</div>
</body>
</html>