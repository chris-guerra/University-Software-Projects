
<html>
<head>
<meta charset="UTF-8">
  <title>Producto</title>
    <style type="text/css">
		body {
			color:  #787878;
			background-color: white}

		h2{
			font-family: Helvetica, Geneva, Arial,
				SunSans-Regular, sans-serif }
		h1{
			font-family: Helvetica, Geneva, Arial,
				SunSans-Regular, sans-serif;
				color: #FF5930				}
		div.bloque1{
			margin-bottom:2em;
			background-color:#50BB7F}
			
		div.logo{
			background-color:white}
			
		div.cat{
			padding-top:1em;
			padding-left:6em}
			
		table.bloques a{
			text-decoration: none;
			color: white;
			}
		
		table.bloques td{
			background-color:#50BB7F;
			padding: 1em;
			padding-left:2em;
			padding-bottom:0.0001em;
			}
			
		table.catalogo{
		font-family: Helvetica, Geneva, Arial,
				SunSans-Regular, sans-serif}
				
		table.catalogo td.desc{
			background-color:#B4B4B4	}
			
		table.catalogo td.izq{
			padding-right:3em}
		
		table.precio{
			color:#50BB7F ;
			padding-left:3em;
			padding-top:2em}
			
		td.agregarcarro a{
			text-decoration: none;
			background-color:#FF5930;
			color: white		}
		
		a.enlace:hover{
			text-decoration: none;
			color:#FF5930}

			
  </style>

</head>

<body>
	<!-- Header -->
	
		
	<div align="left" class="cat">
		
		<table class="catalogo">
			<tr>
				<td class="izq">
					<?php echo "<img src='http://localhost/tarea3grupo4/product_img/".$producto['picture']."' />" ?>
				</td align>
				<td class="der">
					<table align="top">
						<tr>
							<td>
								<h1> Cod. Producto: <?php echo $producto['item']?></h1>
							</td>
						</tr>
					</table>
					<table class="precio">
						<tr align="top">
							<td>
								<h2> Precio: <?php echo $producto['price']?> </h2>
							</td>
						</tr>
						<tr>
							<td>
								Descripcion: <?php echo $producto['comment']?>
							</td>
						</tr>
						<tr>
							<td>
								Tallas: <?php echo $producto['size']?>
							</td>
						</tr>
						<tr>
							<td>
								iva NO incluido
							</td>
						</tr>
						<tr>
							<td class="agregarcarro">
							<?php
							echo "<form action='http://localhost/tarea3grupo4/index.php/carrito/agregar_carro' method='POST'><input type='hidden' name='producto' value=".$producto['item']."><input type='submit' value='(+1) Agregar al carro'></form>"
							?>
							</td>
						</tr>
						
					</table>
				</td>
			</tr>
		</table>
				
	</div>
</body>
</html>
