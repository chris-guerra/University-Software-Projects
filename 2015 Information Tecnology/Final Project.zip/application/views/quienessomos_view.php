<?php
#session_start();
?>
<html>
<head>
<meta charset="UTF-8">
<title>D'kids - Quienes somos</title>
</head>
<body>

				
	<table align="center" class="quienes_somos" >
		<tr>
			<td id="texto">
				<h2><font color="#787878">¿Quiénes Somos?</font></h2>
				<p><font color="#787878">
				Dkids es una tienda que tiene las mejores marcas para tus bebés. Nuestro compromiso radica en entregarte la mejor calidad para tus hijos, lo mejor de la ultima moda, a los mejores precios del mercado.</font></p><p><font color="#787878">Contamos con una tienda física ubicada en Easton Mall Outlet, y también hacemos despachos a lo largo de todo Chile para llevarte todos tus pedidos a la puerta de tu casa.
				</font></p>
			</td>
			<td id="espacio">
			</td>
			<td>
				<img src="http://localhost/tarea3grupo4/imagenes/pendejos.jpg" height="333" width="500" />
			</td>
		</tr>
	</table>
</body>
</html>
